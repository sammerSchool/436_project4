package com.example.finalproject;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import static com.example.finalproject.MainActivity.carArrayList;
import  static com.example.finalproject.SearchViewControl.searchedCar;
import  static  com.example.finalproject.SearchViewControl.displayType;

public class CarViewControl extends AppCompatActivity {
    TextView t1;
    TextView t2;
    TextView t3;
    TextView t4;
    TextView t5;
    TextView t6;
    TextView t7;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i("OPENING THE CARVIEWW", "CARVIEW clicked ");
        setContentView(R.layout.car_view);
        if (displayType){
            Log.i("SET TO TRUE", "DISPLAY SEARCH clicked ");
            displaySearch();
        }
        else if(!displayType){
            Log.i("SET TO FALSE", "DISPLAY ALL clicked ");
            displayAll();
        }
        Button home = findViewById(R.id.homeBtn);

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goHome();
            }
        });



    }

    private void goHome() {
        Log.i("MAIN", "GO HOME BUTTON clicked ");

        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void displaySearch() {

        Log.i("OPENING THE display", "    displaySearch clicked ");

        t1 = findViewById(R.id.textView1);
        t2 = findViewById(R.id.textView2);
        t3 = findViewById(R.id.textView3);
        t4 = findViewById(R.id.textView4);
        t5 = findViewById(R.id.textView5);
        t6 = findViewById(R.id.textView6);
        t7 = findViewById(R.id.textView7);
        int size = searchedCar.size();

        if (size > 0) {
            t1.setText(carArrayList.get(searchedCar.get(0)).getPrice() + "  " + carArrayList.get(searchedCar.get(searchedCar.get(0))).getCondition() + "  " + carArrayList.get(searchedCar.get(0)).getYear()
                    + "  " + carArrayList.get(searchedCar.get(0)).getMake() + "  " + carArrayList.get(searchedCar.get(searchedCar.get(0))).getModel() + "  " + carArrayList.get(searchedCar.get(0)).getColor() + "  " + carArrayList.get(searchedCar.get(0)).getMiles());
        }
        if (size > 1) {
            t2.setText(carArrayList.get(searchedCar.get(1)).getPrice() + "  " + carArrayList.get(searchedCar.get(1)).getCondition() + "  " + carArrayList.get(searchedCar.get(1)).getYear()
                    + "  " + carArrayList.get(searchedCar.get(1)).getMake() + "  " + carArrayList.get(searchedCar.get(1)).getModel() + "  " + carArrayList.get(searchedCar.get(1)).getColor() + "  " + carArrayList.get(searchedCar.get(1)).getMiles());
        }
        if (size > 2) {
            t3.setText(carArrayList.get(searchedCar.get(2)).getPrice() + "  " + carArrayList.get(searchedCar.get(2)).getCondition() + "  " + carArrayList.get(searchedCar.get(2)).getYear()
                    + "  " + carArrayList.get(searchedCar.get(2)).getMake() + "  " + carArrayList.get(searchedCar.get(2)).getModel() + "  " + carArrayList.get(searchedCar.get(2)).getColor() + "  " + carArrayList.get(searchedCar.get(2)).getMiles());
        }
        if (size > 3) {
            t4.setText(carArrayList.get(searchedCar.get(3)).getPrice() + "  " + carArrayList.get(searchedCar.get(3)).getCondition() + "  " + carArrayList.get(searchedCar.get(3)).getYear()
                    + "  " + carArrayList.get(searchedCar.get(3)).getMake() + "  " + carArrayList.get(searchedCar.get(3)).getModel() + "  " + carArrayList.get(searchedCar.get(3)).getColor() + "  " + carArrayList.get(searchedCar.get(3)).getMiles());
        }
        if (size > 4) {
            t5.setText(carArrayList.get(searchedCar.get(4)).getPrice() + "  " + carArrayList.get(searchedCar.get(4)).getCondition() + "  " + carArrayList.get(searchedCar.get(4)).getYear()
                    + "  " + carArrayList.get(searchedCar.get(4)).getMake() + "  " + carArrayList.get(searchedCar.get(4)).getModel() + "  " + carArrayList.get(searchedCar.get(4)).getColor() + "  " + carArrayList.get(searchedCar.get(4)).getMiles());
        }
        if (size > 5) {
            t6.setText(carArrayList.get(searchedCar.get(5)).getPrice() + "  " + carArrayList.get(searchedCar.get(5)).getCondition() + "  " + carArrayList.get(searchedCar.get(5)).getYear()
                    + "  " + carArrayList.get(searchedCar.get(5)).getMake() + "  " + carArrayList.get(searchedCar.get(5)).getModel() + "  " + carArrayList.get(searchedCar.get(5)).getColor() + "  " + carArrayList.get(searchedCar.get(5)).getMiles());
        }
        if (size > 6) {
            t7.setText(carArrayList.get(searchedCar.get(6)).getPrice() + "  " + carArrayList.get(searchedCar.get(6)).getCondition() + "  " + carArrayList.get(searchedCar.get(6)).getYear()
                    + "  " + carArrayList.get(searchedCar.get(6)).getMake() + "  " + carArrayList.get(searchedCar.get(6)).getModel() + "  " + carArrayList.get(searchedCar.get(6)).getColor() + "  " + carArrayList.get(searchedCar.get(6)).getMiles());
        }

    }

    public void displayAll() {

        Log.i("OPENING THE display", "    displayAll clicked ");

        t1 = findViewById(R.id.textView1);
        t2 = findViewById(R.id.textView2);
        t3 = findViewById(R.id.textView3);
        t4 = findViewById(R.id.textView4);
        t5 = findViewById(R.id.textView5);
        t6 = findViewById(R.id.textView6);
        t7 = findViewById(R.id.textView7);
        int size = carArrayList.size();

        if (size > 0) {
            t1.setText(carArrayList.get(0).getPrice() + "  " + carArrayList.get(0).getCondition() + "  " + carArrayList.get(0).getYear()
                + "  " + carArrayList.get(0).getMake() + "  " + carArrayList.get(0).getModel() + "  " + carArrayList.get(0).getColor() + "  " + carArrayList.get(0).getMiles());
        }
        if (size > 1) {
            t2.setText(carArrayList.get(1).getPrice() + "  " + carArrayList.get(1).getCondition() + "  " + carArrayList.get(1).getYear()
                    + "  " + carArrayList.get(1).getMake() + "  " + carArrayList.get(1).getModel() + "  " + carArrayList.get(1).getColor() + "  " + carArrayList.get(1).getMiles());
        }
        if (size > 2) {
            t3.setText(carArrayList.get(2).getPrice() + "  " + carArrayList.get(2).getCondition() + "  " + carArrayList.get(2).getYear()
                    + "  " + carArrayList.get(2).getMake() + "  " + carArrayList.get(2).getModel() + "  " + carArrayList.get(2).getColor() + "  " + carArrayList.get(2).getMiles());
        }
        if (size > 3) {
            t4.setText(carArrayList.get(3).getPrice() + "  " + carArrayList.get(3).getCondition() + "  " + carArrayList.get(3).getYear()
                    + "  " + carArrayList.get(3).getMake() + "  " + carArrayList.get(3).getModel() + "  " + carArrayList.get(3).getColor() + "  " + carArrayList.get(3).getMiles());
        }
        if (size > 4) {
            t5.setText(carArrayList.get(4).getPrice() + "  " + carArrayList.get(4).getCondition() + "  " + carArrayList.get(4).getYear()
                    + "  " + carArrayList.get(4).getMake() + "  " + carArrayList.get(4).getModel() + "  " + carArrayList.get(4).getColor() + "  " + carArrayList.get(4).getMiles());
        }
        if (size > 5) {
            t6.setText(carArrayList.get(5).getPrice() + "  " + carArrayList.get(5).getCondition() + "  " + carArrayList.get(5).getYear()
                    + "  " + carArrayList.get(5).getMake() + "  " + carArrayList.get(5).getModel() + "  " + carArrayList.get(5).getColor() + "  " + carArrayList.get(5).getMiles());
        }
        if (size > 6) {
            t7.setText(carArrayList.get(6).getPrice() + "  " + carArrayList.get(6).getCondition() + "  " + carArrayList.get(6).getYear()
                    + "  " + carArrayList.get(6).getMake() + "  " + carArrayList.get(6).getModel() + "  " + carArrayList.get(6).getColor() + "  " + carArrayList.get(6).getMiles());
        }

    }
}