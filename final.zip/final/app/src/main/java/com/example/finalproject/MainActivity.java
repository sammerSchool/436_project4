package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    public static ArrayList<Car> carArrayList= new ArrayList<Car>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i("OPINGGGGGGG", "THE 1111111 ");
        setContentView(R.layout.activity_main);
        Button sams = findViewById(R.id.samsButton);
        Button search = findViewById(R.id.searchButton);

        sams.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                openOwner();
            }
        });

        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSearch();
            }
        });
    }

    private void openSearch() {
        Log.i("SEARCH", "Button clicked ");

        Intent intent = new Intent(this, SearchViewControl.class);
        startActivity(intent);
    }

    private void openOwner() {
        Log.i("Sams", "Button clicked ");

        Intent intent = new Intent(this, OwnerPageControl.class);
        startActivity(intent);
    }
}
