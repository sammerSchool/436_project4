package com.example.finalproject;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import static com.example.finalproject.MainActivity.carArrayList;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class SearchViewControl extends AppCompatActivity {
    private static final String TAG = "SEARCHVIEWWWWW";
    private Spinner spinner;
    public static ArrayList<Integer> searchedCar= new ArrayList<Integer>();
    public  static  boolean displayType;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.search_view);
        final EditText userInput = findViewById(R.id.userSearch);
        Button search = findViewById(R.id.searchButton);
        final String[] searchBy = new String[1];


        spinner = findViewById(R.id.spinner);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (parent.getItemAtPosition(position).equals("Price")) {
                    searchBy[0] = "Price";

                } else if (parent.getItemAtPosition(position).equals("Condition")) {
                    searchBy[0] = "Condition";

                } else if (parent.getItemAtPosition(position).equals("Year")) {
                    searchBy[0] = "Year";

                } else if (parent.getItemAtPosition(position).equals("Make")) {
                    searchBy[0] = "Make";

                } else if (parent.getItemAtPosition(position).equals("Model")) {
                    searchBy[0] = "Model";

                } else if (parent.getItemAtPosition(position).equals("Color")) {
                    searchBy[0] = "Color";

                } else if (parent.getItemAtPosition(position).equals("Mileage")) {
                    searchBy[0] = "Mileage";

                }
            }
              @Override
              public void onNothingSelected(AdapterView<?> parent) { }  });

        Button home = findViewById(R.id.homeBtn);

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goHome();
            }
        });

        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int numberOfCars = carArrayList.size();
                String userSearch = userInput.getText().toString().trim();
                for (int i = 0; i < numberOfCars; i++){
                    if (searchBy[0].equals("Price")) {
                        if (carArrayList.get(i).getPrice().equals(userSearch)){
                            searchedCar.add(i);
                            displayType = true;
                        }
                    }
                    else if (searchBy[0].equals("Condition")){
                        if (carArrayList.get(i).getCondition().equals(userSearch)){
                            searchedCar.add(i);
                            displayType = true;
                        }

                    }
                    else if (searchBy[0].equals("Year")){
                        if (carArrayList.get(i).getYear().equals(userSearch)){
                        searchedCar.add(i);
                        displayType = true;
                        }

                    }
                    else if (searchBy[0].equals("Make")){
                        if (carArrayList.get(i).getMake().equals(userSearch)){
                            searchedCar.add(i);
                            displayType = true;
                        }
                    }
                    else if (searchBy[0].equals("Model")){
                        if (carArrayList.get(i).getModel().equals(userSearch)){
                            searchedCar.add(i);
                            displayType = true;
                        }
                    }
                    else if (searchBy[0].equals("Color")){
                        if (carArrayList.get(i).getColor().equals(userSearch)){
                            searchedCar.add(i);
                            displayType = true;
                        }
                    }
                    else if (searchBy[0].equals("Mileage")){
                        if (carArrayList.get(i).getMiles().equals(userSearch)){
                            searchedCar.add(i);
                            displayType = true;
                        }
                    }

                }
                displaySearch();

            }
        });

        searchedCar.clear();
    }

    private void goHome() {
            Log.i("SEARCH ", "GO HOME BUTTON clicked ");

        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    private void displaySearch() {
        Intent intent = new Intent(this, CarViewControl.class);
        startActivity(intent);
    }


}

