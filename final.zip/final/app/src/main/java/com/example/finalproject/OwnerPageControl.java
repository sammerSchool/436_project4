package com.example.finalproject;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import  static  com.example.finalproject.SearchViewControl.displayType;

import static com.example.finalproject.MainActivity.carArrayList;

public class OwnerPageControl extends AppCompatActivity {

    EditText price;
    EditText condition;
    EditText year;
    EditText make;
    EditText color;
    EditText model;
    EditText miles;
    EditText editable;
    Button editBtn;
    private static boolean loggedIn;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i("OPENING THE OWWNNNERR", "BOSSSS clicked ");
        setContentView(R.layout.owner_view);
        Button addCarBtn = findViewById(R.id.addBtn);
        Button searchBtn = findViewById(R.id.switchBtn);
        editBtn = findViewById(R.id.editCarBtn);

        Button viewB = findViewById(R.id.viewBtn);


        if (!loggedIn) {
            inflateLogin();
        }

        addCarBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addCar();
            }
        });

        searchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchSwitch();
            }
        });

        viewB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeView();
            }
        });
        if (carArrayList.size() == 0){
            editBtn.setEnabled(false);
        }
        else if (carArrayList.size() > 0){
            editBtn.setEnabled(true);
            editBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    editCar();
                }
            });
        }


}

    private void editCar() {
        Log.i("OPENING THE editCar", "EDITCARR clicked ");
        price= findViewById(R.id.price);
        condition= findViewById(R.id.condition);
        year= findViewById(R.id.year);
        make= findViewById(R.id.make);
        color= findViewById(R.id.color);
        model= findViewById(R.id.model);
        miles= findViewById(R.id.miles);
        editable = findViewById(R.id.editing);
        if (!TextUtils.isEmpty((CharSequence) editable)){
            String carPrice = price.getText().toString().trim();
            String carCondition = condition.getText().toString().trim();
            String carYear = year.getText().toString().trim();
            String carMake = make.getText().toString().trim();
            String carColor = color.getText().toString().trim();
            String carModel = model.getText().toString().trim();
            String carMiles = miles.getText().toString().trim();
            int changing = Integer.parseInt(String.valueOf(editable));

            carArrayList.get(changing).setPrice(carPrice);
            carArrayList.get(changing).setPrice(carCondition);
            carArrayList.get(changing).setPrice(carYear);
            carArrayList.get(changing).setPrice(carMake);
            carArrayList.get(changing).setPrice(carColor);
            carArrayList.get(changing).setPrice(carModel);
            carArrayList.get(changing).setPrice(carMiles);
            Log.i(String.valueOf(carArrayList.size()), "   EDITING THE ARRAY ");
        }
    }

    private void changeView() {
        Log.d(String.valueOf(carArrayList.size()), "   ARRAYSIZE  CHANGE VIEW");
        displayType =false;
        Intent intent = new Intent(this, CarViewControl.class);
        startActivity(intent);
    }

    private void searchSwitch() {
        Intent intent = new Intent(this, SearchViewControl.class);
        startActivity(intent);
    }

    private void addCar() {


        Log.i("OPENING THE addcar", "ADDCARR clicked ");
        Car car = new Car();
        price= findViewById(R.id.price);
        condition= findViewById(R.id.condition);
        year= findViewById(R.id.year);
        make= findViewById(R.id.make);
        color= findViewById(R.id.color);
        model= findViewById(R.id.model);
        miles= findViewById(R.id.miles);
        editBtn = findViewById(R.id.editCarBtn);

        String carPrice = price.getText().toString().trim();
        String carCondition = condition.getText().toString().trim();
        String carYear = year.getText().toString().trim();
        String carMake = make.getText().toString().trim();
        String carColor = color.getText().toString().trim();
        String carModel = model.getText().toString().trim();
        String carMiles = miles.getText().toString().trim();


        car.setPrice(carPrice);
        car.setCondition(carCondition);
        car.setYear(carYear);
        car.setMake(carMake);
        car.setColor(carColor);
        car.setModel(carModel);
        car.setMiles(carMiles);
        carArrayList.add(car);
        if (carArrayList.size() > 0){
            editBtn.setEnabled(true);
        }
        Log.d(String.valueOf(carArrayList.size()), "   ARRAYSIZE ");
    }



    //LOGIN SYSTEM
    private void inflateLogin() {



        LayoutInflater li = LayoutInflater.from(this);
        View login = li.inflate(R.layout.login_prompt, null);
        AlertDialog.Builder alertD = new AlertDialog.Builder(this);
        alertD.setView(login);
        final EditText user = login.findViewById(R.id.loginName);
        final EditText pass = login.findViewById(R.id.loginPass);

        Log.i("alert is sick", "SAMS LOGIN PAGEEEE ");
        alertD.setTitle("SAMS LOGIN PAGEEEE");

        alertD.setCancelable(false)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id)
                    {
                        String username = user.getText().toString();
                        String password = pass.getText().toString();

                        if ( username.equals("admin") || password.equals("pass"))
                        {
                            Log.i("EVERYTHING CORRECT", "CALL  OWNER METHODS");
                            Toast.makeText(OwnerPageControl.this,"Valid username or password", Toast.LENGTH_LONG).show();
                            loggedIn= true;
                        }
                        else
                        {
                            Log.i("EVERYTHING CORRECT", "INFLATING LOGIN");
                            Toast.makeText(OwnerPageControl.this,"Username admin, Password pass", Toast.LENGTH_LONG).show();
                            inflateLogin();
                        }

                    }
                });

        /*alertD.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id)
            {
                dialog.cancel();

            }
        });*/

        alertD.show();
    }
}

